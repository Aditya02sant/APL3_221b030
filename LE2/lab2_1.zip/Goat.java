class Goat extends Animal{
    void makeVoice(){
        System.out.println("Meh meh meh ");
    }
}