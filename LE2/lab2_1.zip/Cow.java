class Cow extends Animal{
    void makeVoice(){
        System.out.println("MOAH");
    }
}