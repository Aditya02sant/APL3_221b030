class Tiger extends Animal{
    void makeVoice(){
        System.out.println("growl");
    }
}