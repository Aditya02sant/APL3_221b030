class Lion extends Animal{
    void makeVoice(){
        System.out.println("Roar");
    }
}