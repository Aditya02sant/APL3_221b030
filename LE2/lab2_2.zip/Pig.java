class Pig extends Animal{
    void makeVoice(){
        System.out.println("Grunts");
    }
}